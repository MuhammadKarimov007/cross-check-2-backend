const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, PutCommand } = require("@aws-sdk/lib-dynamodb");
const { v4: uuidv4 } = require("uuid");

// Initialize DynamoDB Client
const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

const PRODUCTS_TABLE_NAME = process.env.PRODUCTS_TABLE_NAME;
const STOCKS_TABLE_NAME = process.env.STOCKS_TABLE_NAME;

module.exports.handler = async (event) => {
  try {
    // Parse request body
    const requestBody = JSON.parse(event.body);

    // Validate required fields
    if (!requestBody.title || !requestBody.description || !requestBody.price || requestBody.count === undefined) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Missing required fields" }),
      };
    }

    // Generate unique product ID
    const productId = uuidv4();

    // Create new product item
    const newProduct = {
      id: productId,
      title: requestBody.title,
      description: requestBody.description,
      price: requestBody.price,
    };

    // Create stock entry
    const newStock = {
      product_id: productId,
      count: requestBody.count,
    };

    // Save the product and stock to DynamoDB
    await Promise.all([
      docClient.send(new PutCommand({ TableName: PRODUCTS_TABLE_NAME, Item: newProduct })),
      docClient.send(new PutCommand({ TableName: STOCKS_TABLE_NAME, Item: newStock })),
    ]);

    return {
      statusCode: 201,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ ...newProduct, count: newStock.count }),
    };
  } catch (error) {
    console.error("Error creating product:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Internal Server Error" }),
    };
  }
};